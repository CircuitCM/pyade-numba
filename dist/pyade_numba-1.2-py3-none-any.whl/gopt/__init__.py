
#Docy Stringy UwwWU
"""Pyade with end-to-end njit implementations."""

__version__ = '1.2' #One version ahead of the pypi version, also includes fixed population init from original.

__all__ = ["de", "jade", "sade", "shade", "lshade", "ilshade", "lshadecnepsin", "saepsdemmts", "commons", "mpede",
           "jso"]